class LonePair:
    def __init__(self, atom, nr):
        self.nr = nr
        self.parent = atom